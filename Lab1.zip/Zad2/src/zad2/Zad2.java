/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad2;

import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class Zad2 {

    /**
     * @param number
     * @return
     */
    public static boolean isFiveDigit(int number) {
        return (number >= 10000 && number <= 99999);
    }

    public static void main(String[] args) {
        int originalNumber,
                units,
                tens,
                hundreds,
                thousands,
                tenThousands;
        String resultString = "This number is not a palindrome.";
        Scanner in = new Scanner(System.in);

        System.out.println("Enter a five-digit number:");
        originalNumber = in.nextInt();

        if (!isFiveDigit(originalNumber)) {
            System.out.println("You've entered an invalid input.");
            return;
        }

        units = originalNumber % 10;
        originalNumber /= 10;
        tens = originalNumber % 10;
        originalNumber /= 10;
        hundreds = originalNumber % 10;
        originalNumber /= 10;
        thousands = originalNumber % 10;
        tenThousands = originalNumber / 10;
        
        if (units == tenThousands && tens == thousands) {
            resultString = "This number is palindrome.";
        }
        System.out.println(resultString);
    }
}
