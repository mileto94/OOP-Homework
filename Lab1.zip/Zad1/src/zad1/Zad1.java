/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package zad1;

import java.util.Scanner;

/**
 *
 * @author grade
 */
public class Zad1 {

    /**
     * @param fahr
     */
    public static void toCelsius(double fahr) {
        double c;
        c = 5.0 / 9.0 * (fahr - 32);
        System.out.printf("Temperature in Celsuius is %s", c);
        System.out.println("");
    }

    /**
     *
     * @param celsius
     */
    public static void toFahrenheit(double celsius) {
        double f;
        f = 9.0 / 5.0 * celsius + 32;
        System.out.printf("Temperature in Fahrenheit is %s\n", f);
    }

    public static void printMenu() {
        System.out.println("Choose one from the following:");
        System.out.println("1. Enter Celsius to convert to Fahrenheit");
        System.out.println("2. Enter Fahrenheit to convert to Celsius");
        System.out.println("3. Enter to exit");
    }

    public static void main(String[] args) {
        int choice;
        double input;
        printMenu();
        Scanner in = new Scanner(System.in);
        choice = in.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter a number in Fahrenheit:");
                input = in.nextDouble();
                toFahrenheit(input);
                break;
            case 2:
                System.out.println("Enter a number in Celsius:");
                input = in.nextDouble();
                toCelsius(input);
                break;
            case 3:
                return;
            default:
                System.out.println("You've entered invalid number. Try again.");
        }
    }
}
