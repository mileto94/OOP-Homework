/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zad3;

import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class Zad3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int data,
                units,
                tens,
                hundreds,
                thousands,
                swap,
                result;
        System.out.println("Enter a data to be encrypted:");
        Scanner in = new Scanner(System.in);
        
        data = in.nextInt();
        if(data < 1000 || data > 9999) {
            System.out.println("You've entered invalid data.");
            return;
        }
        
        units = data % 10;
        data /= 10;
        tens = data % 10;
        data /= 10;
        hundreds = data % 10;
        thousands = data / 10;
        
        units = (units + 7) % 10;
        tens = (tens + 7) % 10;
        hundreds = (hundreds + 7) % 10;
        thousands = (thousands + 7) % 10;
        
        swap = thousands;
        thousands = tens;
        tens = swap;
        
        swap = hundreds;
        hundreds = units;
        units = swap;
        
        result = thousands * 1000 + hundreds * 100 + tens * 10 + units;
        System.out.printf("Encrypted data is %04d\n", result);
    }
    
}
